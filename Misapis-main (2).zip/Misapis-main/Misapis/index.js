import Server from "./server/server.js";
import 'dotenv/config';
import colors from 'colors';

const server = new Server();
server.listen();