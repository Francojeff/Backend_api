import Ejemplo from '../models/ejemplo.model.js';

export const getEjemplos = async (req, res) => {
    try {
        const ejemplos = await Ejemplo.find({ estado: true });
        res.json({
            msg: 'getEjemplos API',
            total: ejemplos.length,
            ejemplos
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ msg: 'Error al obtener los ejemplos' });
    }
};

export const getEjemploById = async (req, res) => {
    try {
        const { id } = req.params;
        const ejemplo = await Ejemplo.findById(id);

        if (!ejemplo) {
            return res.status(404).json({ msg: `No existe un ejemplo con el id ${id}` });
        }

        res.json({
            msg: 'getEjemploById API',
            ejemplo
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ msg: 'Error al obtener el ejemplo' });
    }
};

export const createEjemplo = async (req, res) => {
    try {
        const body = req.body;

        // Crear instancia del modelo
        const ejemplo = new Ejemplo(body);

        // Guardar en BD
        await ejemplo.save();

        res.status(201).json({
            msg: 'createEjemplo API - POST',
            ejemplo
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ msg: 'Error al crear el ejemplo' });
    }
};

export const updateEjemplo = async (req, res) => {
    try {
        const { id } = req.params;
        const { _id, estado, ...resto } = req.body;

        const ejemplo = await Ejemplo.findByIdAndUpdate(id, resto, { new: true });

        res.json({
            msg: 'updateEjemplo API - PUT',
            ejemplo
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ msg: 'Error al actualizar el ejemplo' });
    }
};

export const deleteEjemplo = async (req, res) => {
    try {
        // En este caso req.query.id según el archivo anterior, pero lo usual es usar param.
        // Adaptaremos a usar param (/:id) para el delete también.
        const { id } = req.params;

        // Borrado lógico
        const ejemplo = await Ejemplo.findByIdAndUpdate(id, { estado: false }, { new: true });

        res.json({
            msg: 'deleteEjemplo API - DELETE',
            ejemplo
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ msg: 'Error al eliminar el ejemplo' });
    }
};
