import mongoose from 'mongoose';

let isConnected = false;

const connectarAMongoDB = async () => {
    if (isConnected) {
        console.log('Ya está conectado a MongoDB');
        return;
    }

    try {
        await mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/misapis');
        isConnected = true;
        console.log('Conexión a MongoDB establecida'.cyan);
    } catch (error) {
        console.log('Error conectando a MongoDB:'.red, error);
    }
};

export default connectarAMongoDB;