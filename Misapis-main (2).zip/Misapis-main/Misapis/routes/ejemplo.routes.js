import { Router } from 'express';
import {
    getEjemplos,
    getEjemploById,
    createEjemplo,
    updateEjemplo,
    deleteEjemplo
} from '../controllers/ejemplo.controller.js';

const ejemplo = Router();

// GET - Obtener todos los ejemplos
ejemplo.get('/', getEjemplos);

// GET - Obtener un ejemplo por ID
ejemplo.get('/:id', getEjemploById);

// POST - Crear un nuevo ejemplo
ejemplo.post('/', createEjemplo);

// PUT - Actualizar un ejemplo por ID
ejemplo.put('/:id', updateEjemplo);

// DELETE - Eliminar (borrado lógico) un ejemplo por ID
ejemplo.delete('/:id', deleteEjemplo);

export default ejemplo;