import mongoose from 'mongoose';

const EjemploSchema = new mongoose.Schema({
    nombre: {
        type: String,
        required: [true, 'El nombre es obligatorio']
    },
    descripcion: {
        type: String,
        required: false
    },
    estado: {
        type: Boolean,
        default: true
    }
}, {
    timestamps: true
});

export default mongoose.model('Ejemplo', EjemploSchema);
